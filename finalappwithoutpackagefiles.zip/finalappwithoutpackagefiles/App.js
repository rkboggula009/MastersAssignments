import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import ErrorBoundary from './ErrorBoundary'; 
import AuthContext, { AuthProvider } from './api/AuthContext';
import MainScreen from './main';
import LoginScreen from './Login';
import SignUpScreen from './signup';
import Cust_home from './customer/cust_home';
import forgot from './forgot';
import EnterOtpScreen from './EnterOtpScreen'
import Restaurant_home from './restaurant/Restaurant_home';
import Rider_home from './rider/Rider_home';
import AddItem from './restaurant/AddItem';
import Cart from './customer/Cart';
import OrderHistoryPage from './customer/OrderHistoryPage';
import ChatScreen from './customer/ChatScreen';
import ItemsList from './customer/ItemsPage';
import ResturantItemList from './restaurant/ResturantItemList';
import ResturantOrderHistoryPage from './restaurant/ResturantOrderHistory';
import OrderDetails from './restaurant/OrderDetails';
import screen from './restaurant/ChatScreen';
import hista from './rider/history';
import chaa from './rider/chatr';
import EditItem from './restaurant/EditItem';
//      //

const Stack = createNativeStackNavigator();

const AppStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Main" component={MainScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
      <Stack.Screen name="SignUp" component={SignUpScreen} options={{ headerShown: false }} />
      <Stack.Screen name= "Cust_home" component={Cust_home} options={{ headerShown: false }} />
      <Stack.Screen name="forgot" component={forgot} options={{ headerShown: false }} />
      <Stack.Screen name="AddItem" component={AddItem} options={{ headerShown: false }} />
      <Stack.Screen name="EnterOtpScreen" component={EnterOtpScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Restaurant_home" component={Restaurant_home} options={{ headerShown: false }}  />
      <Stack.Screen name="ChatScreen" component={ChatScreen} options={{ headerShown: false }} />
      <Stack.Screen name="screen" component={screen} options={{ headerShown: false }}/>
      <Stack.Screen name="ItemsList" component={ItemsList} options={{ headerShown: false }}/>
      <Stack.Screen name="OrderHistoryPage" component={OrderHistoryPage} options={{ headerShown: false }}/>
      <Stack.Screen name="Cart" component={Cart} options={{ headerShown: false }}/>
      <Stack.Screen name="ResturantItemList" component={ResturantItemList} options={{ headerShown: false }} />
      <Stack.Screen name="ResturantOrderHistoryPage" component={ResturantOrderHistoryPage} options={{ headerShown: false }}/>
      <Stack.Screen name="OrderDetails" component={OrderDetails} options={{ headerShown: false }}/>
      <Stack.Screen name="Rider_home" component={Rider_home} options={{ headerShown: false }}/>
      <Stack.Screen name="hist" component={hista} options={{ headerShown: false }}/>
      <Stack.Screen name="chaa" component={chaa} options={{ headerShown: false }}/>
      <Stack.Screen name="EditItem" component={EditItem} options={{ headerShown: false }}/>
    </Stack.Navigator>
  );
};

const App = () => {
  return (
    <AuthProvider>
      <NavigationContainer>
        {/* <ErrorBoundary>  */}
          <AppStack />
        {/* </ErrorBoundary> */}
      </NavigationContainer>
    </AuthProvider>
  );
};

export default App;
