import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet, Dimensions } from 'react-native';

const { width, height } = Dimensions.get('window');

const MainScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <View style={styles.blueRectangle} />
      <View style={styles.curve}>
        <Image 
          source={require('./assets/logo.png')} // Replace with the actual path to the downloaded image
          style={styles.circularImage}
        />
      </View>
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={styles.button}
          //onPress={() => navigation.navigate('Restaurant_home',{ownerEmail:'hyvee@gmail.com'})}
         onPress={() => navigation.navigate('Login')}
        >
          <Text style={styles.buttonText}>Log In</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('SignUp')}
        >
          <Text style={styles.buttonText}>Sign Up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const curveSize = 100; // Adjust the size of the curve here

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'cyan',
  },
  blueRectangle: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: height * 0.5,
    backgroundColor: '#FF6F61',
  },
  curve: {
    position: 'absolute',
    top: height * 0.5 - curveSize,
    left: 0,
    right: 0,
    height: curveSize * 2,
    backgroundColor: '#FF6F61',
    borderBottomLeftRadius: width,
    borderBottomRightRadius: width,
    overflow: 'hidden',
    alignItems: 'center',
  },
  circularImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginTop: curveSize - 100, // Adjust the position to align with the curve
    borderWidth: 5,
    borderColor: '#fff',
    resizeMode: 'contain',
    backgroundColor: '#fff',
  },
  buttonContainer: {
    marginTop: height * 0.5 + curveSize,
    alignItems: 'center',
  },
  button: {
    width: '80%',
    marginTop: '50px',
    padding: 15,
    marginVertical: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FF6F61',
    borderRadius: 20,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

export default MainScreen;
