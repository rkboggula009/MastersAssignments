// api/auth.js
import Config from './urlConfig';
export const performLogin = async (email, password) => {
    try {
      const response = await fetch(`${Config.API_URL}/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
  
      if (!response.ok) {
        throw new Error('Login failed');
      }
  
      const data = await response.json();
      return data.userRole;
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  };
  
// api/auth.js

// api/auth.js

export const performSignUp = async (name, email, password, userType) => {
    try {
      const response = await fetch('http://10.10.114.215:3000/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, email, password, userType }), // Pass userType as the user's role
      });
  
      if (!response.ok) {
        throw new Error('Sign up failed');
      }
  
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Sign up error:', error);
      throw error;
    }
  };
  