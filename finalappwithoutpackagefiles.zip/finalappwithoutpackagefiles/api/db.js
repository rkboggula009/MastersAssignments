// db.js
const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost', // or your database host
  user: 'root', // your database username
  password: '', // your database password
  database: 'food' // your database name
});

connection.connect(err => {
  if (err) {
    console.error('Error connecting to the database:', err);
    return;
  }
  console.log('Successfully connected to the database.');
});

module.exports = connection;
