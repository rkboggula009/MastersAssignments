import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { performLogin } from './api/auth';
import { Ionicons } from '@expo/vector-icons';
import AuthContext from './api/AuthContext'; // Update the path accordingly

const LoginScreen = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigation = useNavigation();
  const { login } = useContext(AuthContext);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Login Error', 'Please fill in both email and password fields.');
      return;
    }
    
    try {
      const userRole = await performLogin(email, password);
      login({ email, role: userRole }); // Save user data in context and AsyncStorage
      console.log(userRole);
      switch (userRole) {
        case 'customer':
          navigation.navigate('Cust_home',{ ownerEmail: email });
          break;
        case 'restaurant':
          console.log(email);
          navigation.navigate('Restaurant_home', { ownerEmail: email }); // Pass ownerEmail as a parameter
          break;
        case 'rider':
          navigation.navigate('Rider_home',{ ownerEmail: email });
          break;
        default:
          Alert.alert('Login Error', 'Invalid user role.');
      }
    } catch (error) {
      console.error('Login error:', error);
      Alert.alert('Login Error', 'An error occurred during login. Please check your credentials and try again.');
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}

    ><TouchableOpacity 
        style={styles.backIconContainer} 
        onPress={() => navigation.goBack()} // Change this to the appropriate navigation function
      >
        <Ionicons name="arrow-back" size={30} color="black" />
      </TouchableOpacity>
    <View style={styles.formContainer1}>
          <View style={styles.slantedBackground1}></View>
          </View>
      <ScrollView contentContainerStyle={styles.scrollView}>
        <Text style={styles.title}>Foodie's Delight</Text>

        <View style={styles.formContainer}>
          <View style={styles.slantedBackground}></View>
          
          <TextInput
            style={styles.input}
            placeholder="Email"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <TextInput
            style={styles.input}
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <TouchableOpacity style={styles.button} onPress={handleLogin}>
            <Text style={styles.buttonText}>Log In</Text>
          </TouchableOpacity>

          <View style={styles.signUpText}>
            <Text>Don't have an account? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
              <Text style={styles.signUpButton}>Sign Up</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.signUpText}>
            <Text>Forgot Password? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('forgot')}>
              <Text style={styles.signUpButton}>Forgot</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  scrollView: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  backIconContainer: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 40 : 20,
    top:40,
    left: 10,
    zIndex: 10,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 24,
    color: '#333',
  },
  formContainer: {
    width: '100%',
    maxWidth: 400,
  },
  slantedBackground: {
    position: 'absolute',
    top: 315,
    left: 0,
    right:10,
    width: '100%',
    height: 100,
    borderBottomWidth: 200,
    borderBottomColor: '#FF6F61',
    borderLeftWidth: 400,
    borderLeftColor: 'transparent',
  },
  slantedBackground1: {
    position: 'absolute',
    top: 0,
    left: -10,
    right:10,
    width: '100%',
    height: 0,
    
    borderTopWidth:200,
    borderTopColor:'#FF6F61',
    borderBottomColor: '#FF6F61',
    borderRightWidth: 400,
    borderRightColor: 'transparent',
  },
  input: {
    width: '100%',
    height: 48,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    paddingHorizontal: 16,
    marginBottom: 16,
    fontSize: 16,
    backgroundColor: '#fff',
  },
  button: {
    width: '100%',
    backgroundColor: '#FF6F61',
    borderRadius: 8,
    paddingVertical: 16,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  signUpText: {
    flexDirection: 'row',
    marginTop: 16,
    justifyContent: 'center',
  },
  signUpButton: {
    color: '#FF6F61',
    fontWeight: 'bold',
  },
});

export default LoginScreen;
