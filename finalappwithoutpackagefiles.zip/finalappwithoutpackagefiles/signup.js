import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Modal,
  Alert,
} from 'react-native';
import Config from './api/urlConfig';
import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';

export const performSignUp = async (name, email, password, userType, location) => {
  try {
    console.log(JSON.stringify({ name, email, password, userType, location }));
    const response = await fetch(`${Config.API_URL}/signup`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name, email, password, userType, location }),
    });
    console.log('after response')
    if (!response.ok) {
      throw new Error('Sign up failed');
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Sign up error:', error);
    throw error;
  }
};

const SignUpScreen = ({ navigation }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [userType, setUserType] = useState('customer');
  const [showDropdown, setShowDropdown] = useState(false);
  const [location, setLocation] = useState(null);

  useEffect(() => {
    getLocation();
  }, []);

  const getLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const location = await Location.getCurrentPositionAsync({});
        setLocation(location.coords);
      }
    } catch (error) {
      console.error('Error getting location:', error);
    }
  };

  const toggleDropdown = () => {
    setShowDropdown(!showDropdown);
  };

  const selectUserType = (type) => {
    setUserType(type);
    setShowDropdown(false);
  };

  const handleSignUp = async () => {
    if (!name || !email || !password || !confirmPassword) {
      Alert.alert('Sign Up Error', 'Please fill in all required fields.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/;

    if (!emailRegex.test(email)) {
      Alert.alert('Sign Up Error', 'Please enter a valid email address.');
      return;
    }
    
    // Password validation check
    if (!passwordRegex.test(password)) {
      Alert.alert('Sign Up Error', 'Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, and one special character (!@#$%^&*).');
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert('Sign Up Error', 'Passwords do not match.');
      return;
    }

    try {
      if (!location) {
        Alert.alert('Location Error', 'Please enable location services to sign up.');
        return;
      }
      
      const response = await performSignUp(name, email, password, userType, location);
      Alert.alert('Success', 'Signup successfully.');
      navigation.navigate('Login');
    } catch (error) {
      console.error('Sign up error:', error);
      Alert.alert('Sign Up Error', 'An error occurred during sign up. Please try again.');
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : null}
      style={styles.container}
    >
      <ScrollView
        contentContainerStyle={styles.scrollViewContent}
        keyboardShouldPersistTaps="handled"
      ><TouchableOpacity onPress={() => navigation.navigate('Main')}>
            <Ionicons name="arrow-back" size={30} color="black" style={styles.backIcon} />
          </TouchableOpacity>
        <View style={styles.formContainer}>
          

          <Text style={styles.title}>Create Your Account</Text>

          <TextInput
            style={styles.input}
            placeholder="Name"
            value={name}
            onChangeText={setName}
          />

          <TextInput
            style={styles.input}
            placeholder="Email"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <TextInput
            style={styles.input}
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <TextInput
            style={styles.input}
            placeholder="Confirm Password"
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            secureTextEntry
          />

          <View style={styles.dropdownContainer}>
            <Text style={styles.dropdownLabel}>User Type:</Text>
            <TouchableOpacity style={styles.dropdownInput} onPress={toggleDropdown}>
              <Text style={styles.buttonText}>{userType}</Text>
            </TouchableOpacity>

            {showDropdown && (
              <View style={styles.dropdown}>
                <TouchableOpacity onPress={() => selectUserType('customer')}>
                  <Text style={styles.dropdownItem}>Customer</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => selectUserType('restaurant')}>
                  <Text style={styles.dropdownItem}>Restaurant</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => selectUserType('rider')}>
                  <Text style={styles.dropdownItem}>Rider</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>

          <TouchableOpacity style={styles.button} onPress={handleSignUp}>
            <Text style={styles.buttonText}>Sign Up</Text>
          </TouchableOpacity>

          <View style={styles.signInText}>
            <Text>Already have an account? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Text style={styles.signInButton}>Sign In</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
      <View style={styles.slantedBackgroundTop}></View>
      <View style={styles.slantedBackgroundBottom}></View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  scrollViewContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  backIcon: {
    position: 'absolute',
    left: 0,
    top: Platform.OS === 'ios' ? 40 : 20, // Adjusted for platform-specific styling
    zIndex: 10,
    top:-119,
  },
  
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 30,
    color: 'black',
    alignSelf: 'center',
    
  },
  input: {
    backgroundColor: 'white',
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 10,
    marginBottom: 15,
    fontSize: 16,
    borderColor: 'black', // Set the border color to blue
    borderWidth: 1, // Set the border width
  },
  
  button: {
    backgroundColor: '#FF6F61',
    borderRadius: 10,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: 'black',
    fontSize: 18,
    fontWeight: 'bold',
  },
  signInText: {
    flexDirection: 'row',
    marginTop: 20,
    justifyContent: 'center',
  },
  signInButton: {
    color: '#FF6F61',
    fontWeight: 'bold',
  },
  dropdownContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  dropdownLabel: {
    fontSize: 16,
    marginRight: 8,
    color: 'black',
  },
  dropdownInput: {
    flex: 1,
    height: 48,
    borderWidth: 1,
    borderColor: 'black',
    borderRadius: 10,
    paddingHorizontal: 16,
    justifyContent: 'center',
    backgroundColor: 'white',
  },
  dropdownText: {
    color: 'black',
    fontSize: 16,
  },
  dropdown: {
    position: 'absolute',
    top: -80,
    left: 0,
    right: 0,
    borderWidth: 1,
    borderColor: 'black',
    borderRadius: 10,
    backgroundColor: 'white',
  },
  dropdownItem: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'black',
  },
});

export default SignUpScreen;