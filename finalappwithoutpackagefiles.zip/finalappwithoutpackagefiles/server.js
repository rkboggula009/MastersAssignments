const express = require('express');
const bcrypt = require('bcryptjs');
const mysql = require('mysql2');
const nodemailer = require('nodemailer');


const app = express();
app.use(express.json());

// Create reusable transporter object using SMTP transport
const transporter = nodemailer.createTransport({
  host: "smtp.office365.com", // Office 365 server
  port: 587, // SMTP Port
  secure: false, // false for TLS
  auth: {
    user: 'patlolla@crmwebx.com', // Replace with your email
    pass: 'Venk@tib9DJ@456' // Replace with your email password
  }
});

// Function to send OTP email
function sendOTPEmail(email, otp) {
  const mailOptions = {
    from: 'patlolla@crmwebx.com', // Sender address
    to: email, // Receiver address (passed to the function)
    subject: 'Your OTP for Password Reset',
    text: `Your OTP is: ${otp}. It is valid for 15 minutes.`
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log('Error sending email:', error);
    } else {
      console.log('Email sent:', info.response);
    }
  });
}

// Set up your MySQL connection
const db = mysql.createConnection({
  host: 'localhost', // Replace with your database host
  user: 'root', // Replace with your database username
  password: '', // Replace with your database password
  database: 'food' // Replace with your database name
});

db.connect(err => {
  if (err) {
    console.error('Error connecting to the database:', err);
    return;
  }
  console.log('Successfully connected to the database.');
});

// Login endpoint
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  console.log('Login request:', email, password); // Log incoming request data

  db.query('SELECT * FROM users WHERE username = ?', [email], (err, results) => {
    if (err) {
      console.error('Database query error:', err);
      res.status(500).json({ message: 'Error querying the database', error: err });
      return;
    }

    if (results.length > 0) {
      const user = results[0];
      if (bcrypt.compareSync(password, user.password)) {
        console.log('User authenticated successfully:', user.username);
        res.json({ userRole: user.role });
      } else {
        console.error('Password mismatch for user:', user.username);
        res.status(401).json({ message: 'Invalid credentials' });
      }
    } else {
      console.error('User not found:', email);
      res.status(401).json({ message: 'User not found' });
    }
  });
});

// Signup endpoint
app.post('/signup', (req, res) => {
    const { name, email, password, userType, location } = req.body;
    console.log('Signup request:', name, email, password); // Log incoming request data
    const latitude = location.latitude;
    const longitude = location.longitude;
    // Check if the user already exists in the database
    db.query('SELECT * FROM users WHERE username = ?', [email], (err, results) => {
      if (err) {
        console.error('Database query error:', err);
        res.status(500).json({ message: 'Error querying the database', error: err });
        return;
      }
  
      if (results.length > 0) {
        console.error('User already exists:', email);
        res.status(400).json({ message: 'User already exists' });
        return;
      }
  
      // Hash the password before storing it in the database
      const hashedPassword = bcrypt.hashSync(password, 10);
  
      // Insert the new user into the database
      db.query('INSERT INTO users (name, username, password, role, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?)', [name, email, hashedPassword, userType, latitude, longitude], (err, result) => {
        if (err) {
          console.error('Database insertion error:', err);
          res.status(500).json({ message: 'Error inserting data into the database', error: err });
          return;
        }
  
        console.log('User registered successfully:', email);
        res.status(201).json({ message: 'User registered successfully' });
      });
    });
  });
//   to fetch the username to display
app.get('/getUserName', (req, res) => {
  // Get the username from the request, e.g., from a query parameter or a token
  const username = req.query.username; // or req.body.username, or decode from a token

  // Query the database to get the user's name using the username
  const query = 'SELECT name FROM users WHERE username = ?';
  db.query(query, [username], (error, results) => {
    if (error) {
      console.error('Error querying MySQL:', error);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    if (results.length === 0) {
      res.status(404).json({ error: 'User not found' });
    } else {
      const userName = results[0].name;
      res.json({ userName });
    }
  });
});


app.post('/reset-password', (req, res) => {
  const { email, otp, newPassword } = req.body;

  // Verify OTP and expiration time
  const query = 'SELECT * FROM users WHERE username = ? AND resetPasswordOTP = ? AND resetPasswordExpires > NOW()';
  db.query(query, [email, otp], (error, results) => {
    if (error) {
      console.error('Error verifying OTP:', error);
      res.status(500).json({ message: 'Error verifying OTP' });
      return;
    }

    if (results.length === 0) {
      res.status(400).json({ message: 'Invalid or expired OTP' });
      return;
    }

    const hashedPassword = bcrypt.hashSync(newPassword, 10);

    // Update user's password
    const updateQuery = 'UPDATE users SET password = ? WHERE username = ?';
    db.query(updateQuery, [hashedPassword, email], (updateError, updateResults) => {
      if (updateError) {
        console.error('Error updating user password:', updateError);
        res.status(500).json({ message: 'Error updating user password' });
        return;
      }

      res.json({ message: 'Password updated successfully' });
    });
  });
});

app.post('/request-password-reset', (req, res) => {
  const { email } = req.body;
  const otp = Math.floor(100000 + Math.random() * 900000); // Generate 6-digit OTP
  const expireTime = new Date(Date.now() + 15 * 60000); // 15 minutes from now

  // Store OTP in the database
  const query = 'UPDATE users SET resetPasswordOTP = ?, resetPasswordExpires = ? WHERE username = ?';
  db.query(query, [otp, expireTime, email], (error, results) => {
    if (error) {
      console.error('Error updating user with OTP:', error);
      res.status(500).json({ message: 'Error updating user with OTP' });
      return;
    }

    if (results.affectedRows === 0) {
      res.status(404).json({ message: 'User not found' });
      return;
    }

    // Send email with OTP (pseudo-code, replace with your email sending logic)
    sendOTPEmail(email, otp);

    res.json({ message: 'OTP sent to email' });
  });
});

//Resturant calls
app.post('/api/addItem', (req, res) => {
  const { itemName, itemPrice, itemDescription, itemImage, ownerEmail } = req.body;
  const sql = 'INSERT INTO items (itemName, itemPrice, itemDescription, itemImage, ownerEmail) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [itemName, itemPrice, itemDescription, itemImage, ownerEmail], (err, result) => {
    if (err) {
      console.error('Error adding item:', err);
      res.status(500).send('Error adding item');
    } else {
      console.log('Item added successfully');
      res.status(200).send('Item added successfully');
    }
  });
});

app.post('/api/updateItem', (req, res) => {
  const { id, itemName, itemPrice, itemDescription } = req.body;
  const sql = 'UPDATE items SET itemName=?, itemPrice=?, itemDescription=? WHERE id=?';
  db.query(sql, [itemName, itemPrice, itemDescription, id], (err, result) => {
    if (err) {
      console.error('Error updating item:', err);
      res.status(500).send('Error updating item');
    } else {
      console.log('Item updated successfully');
      res.status(200).send('Item updated successfully');
    }
  });
});


app.get('/api/getItems', async (req, res) => {
  try {
    // Assuming you pass the owner's email as a query parameter, for example: /api/getItems?ownerEmail=user@example.com
    const ownerEmail = req.query.ownerEmail;

    // Query to retrieve items from the database based on owner's email
    const query = 'SELECT * FROM items WHERE ownerEmail = ?';

    db.query(query, [ownerEmail], (error, results) => {
      if (error) {
        console.error('Error querying MySQL:', error);
        res.status(500).json({ error: 'Internal Server Error' });
        return;
      }

      res.status(200).json(results);
    });
  } catch (error) {
    console.error('Error fetching items:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Logout endpoint
app.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Error destroying session:', err);
      res.status(500).json({ error: 'Error destroying session' });
      return;
    }
    res.clearCookie('connect.sid');
    res.json({ message: 'Logged out successfully' });
  });
});

app.post('/api/placeOrder', (req, res) => {
  console.log('Before inserting order');
  const { customerId, items, totalAmount, restaurant } = req.body;

  // Retrieve latitude and longitude of the customer
  const getCustomerLocationQuery = 'SELECT latitude, longitude FROM users WHERE username = ?';
  db.query(getCustomerLocationQuery, [customerId], (err, customerLocationResult) => {
    if (err) {
      console.error('Error retrieving customer location:', err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    if (customerLocationResult.length === 0) {
      console.error('Customer location not found');
      res.status(404).json({ error: 'Customer location not found' });
      return;
    }

    const { latitude: customerLatitude, longitude: customerLongitude } = customerLocationResult[0];

    // Retrieve latitude and longitude of the restaurant
    const getRestaurantLocationQuery = 'SELECT latitude, longitude FROM users WHERE username = ?';
    db.query(getRestaurantLocationQuery, [restaurant], (err, restaurantLocationResult) => {
      if (err) {
        console.error('Error retrieving restaurant location:', err);
        res.status(500).json({ error: 'Internal Server Error' });
        return;
      }

      if (restaurantLocationResult.length === 0) {
        console.error('Restaurant location not found');
        res.status(404).json({ error: 'Restaurant location not found' });
        return;
      }

      const { latitude: restaurantLatitude, longitude: restaurantLongitude } = restaurantLocationResult[0];

      // Insert the order into the database
      const insertOrderQuery = 'INSERT INTO orders (customerId, items, totalAmount, restaurant, status, createdAt, customerLatitude, customerLongitude, restaurantLatitude, restaurantLongitude) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
      db.query(insertOrderQuery, [customerId, JSON.stringify(items), totalAmount, restaurant, 'pending', new Date(), customerLatitude, customerLongitude, restaurantLatitude, restaurantLongitude], (err, result) => {
        if (err) {
          console.error('Error inserting order:', err);
          res.status(500).json({ error: 'Internal Server Error' });
        } else {
          console.log('Order inserted successfully:', result);
          res.json({ message: 'Order placed successfully' });
        }
      });
    });
  });
});

app.get('/api/orders', (req, res) => {
  const { restaurant } = req.query;
  const sql = `SELECT * FROM orders WHERE restaurant = ?`;
  db.query(sql, [restaurant], (err, results) => {
      if (err) {
          res.status(500).json({ error: 'Error fetching orders' });
          return;
      }
      res.json(results);
      console.log(res)
  });
});


app.get('/api/getOrders', async (req, res) => {
  const customerId = req.query.customerId;
  const query = 'SELECT * FROM orders WHERE customerId = ?';
  try {
    // Assuming you have a MySQL connection (db) established
    db.query(query, [customerId], (error, results) => {
      if (error) {
        console.error('Error querying MySQL:', error);
        res.status(500).json({ error: 'Internal Server Error' });
        return;
      }
      console.log(results);
      res.json(results);
    });
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


// Signup endpoint
app.post('/signup', (req, res) => {
  const { name, email, password, userType } = req.body;
  console.log('Signup request:', name, email, password, userType); // Log incoming request data

  // Check if the user already exists in the database
  db.query('SELECT * FROM users WHERE username = ?', [email], (err, results) => {
    if (err) {
      console.error('Database query error:', err);
      res.status(500).json({ message: 'Error querying the database', error: err });
      return;
    }

    if (results.length > 0) {
      console.error('User already exists:', email);
      res.status(400).json({ message: 'User already exists' });
      return;
    }

    // Hash the password before storing it in the database
    const hashedPassword = bcrypt.hashSync(password, 10);

    // Insert the new user into the database
    db.query('INSERT INTO users (name, username, password, role) VALUES (?, ?, ?, ?)', [name, email, hashedPassword, userType], (err, result) => {
      if (err) {
        console.error('Database insertion error:', err);
        res.status(500).json({ message: 'Error inserting data into the database', error: err });
        return;
      }

      console.log('User registered successfully:', email);
      res.status(201).json({ message: 'User registered successfully' });
    });
  });
});

// Add Food Item endpoint
// Add Food Item endpoint
app.post('/addFoodItem', (req, res) => {
  const { name, price, image } = req.body;
  console.log('addFoodItem'+req.body);
  // Get the id (assuming it's named 'id') from the session for the logged-in user
  const userId = req.session.user ? req.session.user.id : null;

  // Check if user is logged in
  if (!userId) {
    res.status(401).json({ message: 'Unauthorized' });
    return;
  }

  // Fetch the user details to get the role
  const getUserQuery = 'SELECT * FROM users WHERE id = ?';
  db.query(getUserQuery, [userId], (getUserError, userResults) => {
    if (getUserError) {
      console.error('Error fetching user details:', getUserError);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    if (userResults.length === 0) {
      console.error('User not found');
      res.status(404).json({ error: 'User not found' });
      return;
    }

    const user = userResults[0];

    if (user.role !== 'restaurant') {
      res.status(401).json({ message: 'Unauthorized' });
      return;
    }

    const partnerId = userId; // Use the userId as the partnerId for the restaurant

    // Insert the food item with the fetched 'partnerId'
    const query = 'INSERT INTO menuItems (name, price, image, partnerId) VALUES (?, ?, ?, ?)';
    db.query(query, [name, price, image, partnerId], (error, results) => {
      if (error) {
        console.error('Error adding food item:', error);
        res.status(500).json({ error: 'Internal Server Error' });
        return;
      }

      console.log('Food item added successfully:', name);
      res.status(201).json({ message: 'Food item added successfully' });
    });
  });
});

app.put('/update-order/:id', (req, res) => {
  const { id } = req.params;
  const { ownerEmail } = req.body; // Corrected variable name
  
  // Update the order in the database
  const sql = `UPDATE orders SET rider_owner_email = ? WHERE id = ?`;
  db.query(sql, [ownerEmail, id], (err, result) => {
    if (err) {
      console.error('Error updating order:', err);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    console.log('Order updated successfully');
    res.json({ message: 'Order updated successfully' });
  });
});

// API endpoint to handle updating order status to 'completed'
app.put('/update-order-status/:orderId', (req, res) => {
  const { orderId } = req.params;
  const { status } = req.body;

  // Update order status in the database
  const query = `UPDATE orders SET status = ? WHERE id = ?`;
  db.query(query, [status, orderId], (error, results) => {
    if (error) {
      console.error('Error updating order status:', error);
      res.status(500).json({ error: 'Failed to update order status' });
      return;
    }

    console.log('Order status delier updated successfully');
    res.status(200).json({ message: 'Order status updated successfully' });
  });
});




app.put('/updateRestaurant', (req, res) => {
  const { restaurantName, location } = req.body;
  const userId = req.session.user ? req.session.user.id : null;

  if (!userId) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  // Check if data already exists for the user in the restaurants table
  const checkIfExistsQuery = 'SELECT * FROM restaurants WHERE user_id = ?';
  db.query(checkIfExistsQuery, [userId], (checkError, checkResults) => {
    if (checkError) {
      console.error('Error checking existing data:', checkError);
      return res.status(500).json({ error: 'Internal Server Error' });
    }

    if (checkResults.length === 0) {
      // If no data exists, perform an INSERT
      const insertQuery = 'INSERT INTO restaurants (name, location, user_id) VALUES (?, ?, ?)';
      db.query(insertQuery, [restaurantName, location, userId], (insertError, insertResults) => {
        if (insertError) {
          console.error('Error inserting data:', insertError);
          return res.status(500).json({ error: 'Internal Server Error' });
        }
        return res.status(200).json({ message: 'Restaurant details inserted successfully' });
      });
    } else {
      // If data exists, perform an UPDATE
      const updateQuery = 'UPDATE restaurants SET name = ?, location = ? WHERE user_id = ?';
      db.query(updateQuery, [restaurantName, location, userId], (updateError, updateResults) => {
        if (updateError) {
          console.error('Error updating data:', updateError);
          return res.status(500).json({ error: 'Internal Server Error' });
        }
        return res.status(200).json({ message: 'Restaurant details updated successfully' });
      });
    }
  });
});



// Change Password

app.put('/changePassword', async (req, res) => {
  const { currentPassword, newPassword } = req.body;

  // Get the user ID from the session or token
  const userId = req.session.user ? req.session.user.id : null;

  if (!userId) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  // Fetch user's current password hash from the database
  const getPasswordQuery = 'SELECT password FROM users WHERE id = ?';

  db.query(getPasswordQuery, [userId], async (error, results) => {
    if (error) {
      console.error('Error fetching user password:', error);
      return res.status(500).json({ error: 'Internal Server Error' });
    }

    if (results.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    const userPasswordHash = results[0].password;

    // Compare the provided current password with the stored password hash
    const passwordMatch = await bcrypt.compare(currentPassword, userPasswordHash);

    if (!passwordMatch) {
      return res.status(400).json({ message: 'Current password is incorrect' });
    }

    // Hash the new password before updating in the database
    const hashedNewPassword = await bcrypt.hash(newPassword, 10);

    // Update the password hash in the database
    const updatePasswordQuery = 'UPDATE users SET password = ? WHERE id = ?';

    db.query(updatePasswordQuery, [hashedNewPassword, userId], (updateError, updateResults) => {
      if (updateError) {
        console.error('Error updating password:', updateError);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      return res.status(200).json({ message: 'Password changed successfully' });
    });
  });
});

app.get('/getUserDetails', (req, res) => {
  const userId = req.session.user ? req.session.user.id : null;

  if (!userId) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  const getUsernameQuery = 'SELECT username FROM users WHERE id = ?';
  db.query(getUsernameQuery, [userId], (error, results) => {
    if (error) {
      console.error('Error fetching user details:', error);
      return res.status(500).json({ error: 'Internal Server Error' });
    }

    if (results.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const { username } = results[0];
    return res.status(200).json({ username });
  });
});


// Endpoint to get restaurant details by ID
app.get('/restaurants/:id', (req, res) => {
  const restaurantId = req.params.id;
  connection.query('SELECT * FROM restaurants WHERE id = ?', [restaurantId], (err, results) => {
    if (err) {
      console.error('Error fetching restaurant details:', err);
      res.status(500).json({ error: 'Error fetching restaurant details' });
      return;
    }
    if (results.length === 0) {
      res.status(404).json({ error: 'Restaurant not found' });
      return;
    }
    res.json(results[0]); // Assuming you'll receive a single restaurant object
  });
});

// Get User Name endpoint
app.get('/getUserName', (req, res) => {
  // Get the username from the request, e.g., from a query parameter or a token
  const username = req.query.username; // or req.body.username, or decode from a token

  // Check if user is logged in
  if (!req.session.user) {
    res.status(401).json({ message: 'Unauthorized' });
    return;
  }
  
  
  // Query the database to get the user's name using the username
  const query = 'SELECT name FROM users WHERE username = ?';
  db.query(query, [username], (error, results) => {
    if (error) {
      console.error('Error querying MySQL:', error);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    if (results.length === 0) {
      res.status(404).json({ error: 'User not found' });
    } else {
      const userName = results[0].name;
      res.json({ userName });
    }
  });
});
app.get('/restaurants', (req, res) => {
  console.log('Handling GET request for /restaurants');
  
  // Assuming the role value is sent in the request query as 'role'
  const role = 'restaurant';

  // Adjust the query to fetch users with the specified role
  const query = 'SELECT * FROM users WHERE role = ?';
  db.query(query, [role], (err, result) => {
    if (err) {
      console.error('Error executing query:', err);
      res.status(500).send('Internal Server Error');
    } else {
      console.log('Query result:', result);
      res.json(result);
    }
  });
});

// Endpoint to update order status
app.put('/api/orders/:orderId/status', (req, res) => {
  const orderId = req.params.orderId;
  const { status } = req.body;

  // Execute the SQL query to update the order status
  const query = 'UPDATE orders SET status = ? WHERE id = ?';
  db.query(query, [status, orderId], (error, results) => {
    if (error) {
      console.error('Error updating order status:', error);
      return res.status(500).json({ error: 'Failed to update order status' });
    }

    // Check if the order was updated successfully
    if (results.affectedRows === 1) {
      return res.status(200).json({ message: 'Order status updated successfully' });
    } else {
      return res.status(404).json({ error: 'Order not found' });
    }
  });
});


app.get('/menuitems', (req, res) => {
  const query = 'SELECT * FROM menuitems';

  db.query(query, (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    res.json(results);
  });
});

app.get('/api/orders/:restaurant', (req, res) => {
  const { restaurant } = req.params;
  console.log(restaurant);
  const sql = `
    SELECT 
      o.id, 
      u.name, 
      o.items, 
      o.totalAmount, 
      o.restaurant, 
      o.status, 
      o.createdAt, 
      o.customerLatitude, 
      o.customerLongitude, 
      o.restaurantLatitude, 
      o.restaurantLongitude
    FROM 
      orders o
    INNER JOIN 
      users u
    ON 
      o.customerId = u.username
    WHERE 
      o.restaurant = ? 
    AND 
      o.status = "pending"`;


  db.query(sql, [restaurant], (err, results) => {
    if (err) {
      console.error('Error fetching orders:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
});


app.get('/pending-orders', (req, res) => {
  const ownerEmail = req.query.ownerEmail;
  console.log('backend');
  const sql = `SELECT * FROM orders 
    WHERE (status = 'pending' OR status = 'processed') 
    AND (rider_owner_email = '${ownerEmail}' OR rider_owner_email IS NULL)`;
  
  

  db.query(sql, (err, result) => {
    if (err) {
      console.error('Error fetching pending orders:', err);
      res.status(500).send('Error fetching pending orders');
    } else {
      res.json(result);
      //console.log(result);
    }
  });
});


app.get('/history', async (req, res) => {
  const { riderEmail } = req.query; 

  try {
    // Execute SQL query to fetch historical orders for the given rider email
    db.query(
      'SELECT * FROM orders WHERE rider_owner_email = ?',
      [riderEmail],
      (error, results) => {
        if (error) {
          console.error('Error fetching history:', error);
          res.status(500).json({ error: 'Internal server error' });
          return;
        }

        //console.log('Fetched orders:', results); // Log the fetched orders
        res.json(results); // Send the fetched orders as JSON response
      }
    );
  } catch (error) {
    console.error('Error fetching history:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


app.get('/api/ses/:restaurant', (req, res) => {
  const { restaurant } = req.params;
  //console.log(restaurant);
  const sql = 'SELECT * FROM orders WHERE restaurant = ?';
  db.query(sql, [restaurant], (err, results) => {
    if (err) {
      console.error('Error fetching orders:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
});

app.put('/api/orders/:orderId', (req, res) => {
  const orderId = req.params.orderId;
  const { status } = req.body;
  const sql = 'UPDATE orders SET status = ? WHERE id = ?';
  
  db.query(sql, [status, orderId], (err, result) => {
    if (err) {
      console.error('Error updating order:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      if (result.affectedRows === 0) {
        // If no rows were affected, it means the order ID doesn't exist
        res.status(404).json({ error: 'Order not found' });
      } else {
        // Order status updated successfully
        res.json({ message: 'Order status updated successfully' });
      }
    }
  });
});


// Get all items for a restaurant
app.get('/api/items/:ownerEmail', (req, res) => {
  const ownerEmail = req.params.ownerEmail;
  const sql = 'SELECT * FROM items WHERE ownerEmail = ?';
  db.query(sql, [ownerEmail], (err, results) => {
    if (err) {
      console.error('Error fetching items:', err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }
    res.json(results);
  });
});

// Create new item
app.post('/api/items', (req, res) => {
  const newItem = req.body;
  const sql = 'INSERT INTO items SET ?';
  db.query(sql, [newItem], (err, result) => {
    if (err) {
      console.error('Error creating item:', err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }
    newItem.id = result.insertId;
    res.status(201).json(newItem);
  });
});

// Delete item by ID
app.delete('/api/items/:itemId', (req, res) => {
  const itemId = parseInt(req.params.itemId);

  // Construct the SQL query to delete the item from the database
  const sql = 'DELETE FROM items WHERE id = ?';

  // Execute the SQL query with the itemId parameter
  db.query(sql, [itemId], (err, result) => {
    if (err) {
      console.error('Error deleting item:', err);
      return res.status(500).json({ error: 'Internal Server Error' });
    }

    // Check if any rows were affected by the delete operation
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Item not found' });
    }

    // Item deleted successfully
    res.json({ message: 'Item deleted successfully' });
  });
});



// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://10.10.129.40:${PORT}`);
});
