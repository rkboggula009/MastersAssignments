import React from 'react';
import { WebView } from 'react-native-webview';

const LiveChatWidget = () => {
  return (
    <WebView
      source={{ uri: 'https://direct.lc.chat/17734827/'}}
      style={{ flex: 1 }}
    />
  );
};

export default LiveChatWidget;
