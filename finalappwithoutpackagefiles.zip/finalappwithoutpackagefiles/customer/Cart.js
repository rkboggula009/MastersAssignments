import React, { useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { CardField, useStripe, createPaymentMethod } from '@stripe/stripe-react-native'; // Import Stripe components
import Config from '../api/urlConfig';

const CartScreen = ({ route, navigation }) => {
  const { selectedItems, items, User, restaurantEmail } = route.params;
  const [orderPlacedMessage, setOrderPlacedMessage] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const { confirmPayment } = useStripe(); // Initialize Stripe hook
  const [updatedSelectedItems, setUpdatedSelectedItems] = useState(selectedItems); // State to manage item quantities

  const placeOrder = async () => {
    try {
      const totalAmount = calculateTotalPrice();
      // Create payment method with card details
      const paymentMethod = await createPaymentMethod({
        paymentMethodType: 'Card',
        card: {
          number: cardNumber,
          expMonth: expiryDate.split('/')[0],
          expYear: expiryDate.split('/')[1],
          cvc: cvv,
        },
      });
      // Verify if the card is valid
      if (paymentMethod.error) {
        console.log('payment error')
      }
      // If card is valid, proceed to place the order
      const response = await fetch(`${Config.API_URL}/api/placeOrder`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          customerId: User,
          items: Object.keys(updatedSelectedItems).map((itemId) => ({
            itemId,
            quantity: updatedSelectedItems[itemId],
          })),
          totalAmount,
          restaurant: restaurantEmail,
        }),
      });
      const data = await response.json();
      if (data.message === 'Order placed successfully') {
        setOrderPlacedMessage(`Order placed successfully! Order ID: ${data.orderId}`);
        // Clear card details
        setCardNumber('');
        setExpiryDate('');
        setCvv('');
      } else {
        setOrderPlacedMessage('Failed to place order. Please try again.');
      }      
    } catch (error) {
      console.error('Error placing order:', error.message);
      setOrderPlacedMessage('Failed to place order. Please try again.');
    }
  };

  const calculateTotalPrice = () => {
    const totalPrice = Object.keys(updatedSelectedItems).reduce((total, itemId) => {
      const quantity = updatedSelectedItems[itemId];
      const item = items.find((item) => item.id == itemId);

      if (item && typeof item.itemPrice == 'string') {
        const itemTotal = parseFloat(item.itemPrice) * quantity;
        total += itemTotal;
      }

      return total;
    }, 0);

    return totalPrice;
  };

  const handleQuantityChange = (itemId, change) => {
    const newQuantity = updatedSelectedItems[itemId] + change;
    if (newQuantity >= 0) {
      const updatedItems = { ...updatedSelectedItems, [itemId]: newQuantity };
      setUpdatedSelectedItems(updatedItems);
    }
  };

  const renderCartItem = ({ item }) => (
    <View style={styles.cartItem}>
      <Text style={styles.itemName}>{item.itemName}</Text>
      <Text style={styles.itemPrice}>{item.itemPrice}</Text>
      <View style={styles.quantityContainer}>
        <TouchableOpacity onPress={() => handleQuantityChange(item.id, -1)}>
          <Text style={styles.quantityButton}>-</Text>
        </TouchableOpacity>
        <Text style={styles.quantityText}>{updatedSelectedItems[item.id] || 0}</Text>
        <TouchableOpacity onPress={() => handleQuantityChange(item.id, 1)}>
          <Text style={styles.quantityButton}>+</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Shopping Cart</Text>
      <FlatList
        data={items.filter((item) => updatedSelectedItems[item.id])}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderCartItem}
      />
      <Text style={styles.totalPrice}>Total Price: ${calculateTotalPrice().toFixed(2)}</Text>
      {/* Payment Section */}
      <CardField
        postalCodeEnabled={false}
        placeholder={{
          number: 'Card Number',
          expiration: 'MM/YY',
          cvc: 'CVC',
        }}
        cardStyle={styles.card}
        style={styles.cardField}
        onCardChange={(cardDetails) => {
          setCardNumber(cardDetails?.number);
          setExpiryDate(cardDetails?.expMonth && cardDetails?.expYear ? `${cardDetails?.expMonth}/${cardDetails?.expYear}` : '');
          setCvv(cardDetails?.cvc);
        }}
      />
      <TouchableOpacity style={styles.placeOrderButton} onPress={placeOrder}>
        <Text style={styles.placeOrderButtonText}>Place Order</Text>
      </TouchableOpacity>
      {orderPlacedMessage ? <Text style={styles.orderPlacedMessage}>{orderPlacedMessage}</Text> : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#333',
  },
  cartItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    paddingVertical: 12,
  },
  itemName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  itemPrice: {
    fontSize: 16,
    color: '#777',
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  quantityText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#555',
    marginHorizontal: 10,
  },
  quantityButton: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#00f',
  },
  totalPrice: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 20,
    textAlign: 'right',
    color: '#333',
  },
  placeOrderButton: {
    backgroundColor: '#ff5733',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
    elevation: 3,
  },
  placeOrderButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    textTransform: 'uppercase',
  },
  orderPlacedMessage: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#00c853',
    marginTop: 20,
    textAlign: 'center',
  },
  cardField: {
    width: '100%',
    height: 50,
    marginVertical: 10,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    color: '#000000',
  },
});

export default CartScreen;
