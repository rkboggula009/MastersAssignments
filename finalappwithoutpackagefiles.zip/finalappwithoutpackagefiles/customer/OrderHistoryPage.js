import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, Image } from 'react-native';
import Config from '../api/urlConfig';

const OrderHistoryPage = ({ route }) => {
  const { customerId } = route.params;
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const response = await fetch(`${Config.API_URL}/api/getOrders?customerId=${customerId}`);
      if (response.ok) {
        const data = await response.json();
        setOrders(data);
      } else {
        console.error('Error fetching orders:', response.status);
      }
    } catch (error) {
      console.error('Error fetching orders:', error.message);
    }
  };

  const renderOrderItem = ({ item }) => (
    <View style={styles.orderItem}>
      <Text style={styles.orderHeader}>Order ID: {item.id}</Text>
      <Text>Customer ID: {item.customerId}</Text>
      {Array.isArray(item.items) ? (
        <Text style={styles.orderDetails}>
          {item.items.map((item) => `${item.quantity} x ${item.itemName}`).join('\n')}
        </Text>
      ) : (
        <Text>{item.items}</Text>
      )}
      <Text>Total Price: ${parseFloat(item.totalAmount).toFixed(2)}</Text>
      <Text>Order Date: {new Date(item.createdAt).toLocaleString()}</Text>
      <Text>Status: {item.status}</Text>
      <Image
        source={require('../assets/logo.png')} 
        style={styles.staticImage}
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Order History</Text>
      <FlatList
        data={orders}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderOrderItem}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: 16,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
    textAlign: 'center',
  },
  orderItem: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 16,
    marginBottom: 16,
    elevation: 3,
  },
  orderHeader: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  orderDetails: {
    marginBottom: 8,
  },
  staticImage: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 80,
    height: 80,
    borderRadius: 50,
  },
});

export default OrderHistoryPage;
