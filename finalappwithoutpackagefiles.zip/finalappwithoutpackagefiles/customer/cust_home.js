import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, TextInput, StyleSheet, Image } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import Swiper from 'react-native-swiper';
import Config from '../api/urlConfig';
import Modal from 'react-native-modal';

const UserProfile = ({route, navigation }) => {
  const {ownerEmail } = route.params;
  const [restaurants, setRestaurants] = useState([]); // State to store restaurant data
  const [searchQuery, setSearchQuery] = useState('');
  const [logoutPopupVisible, setLogoutPopupVisible] = useState(false);
  const [searchModalVisible, setSearchModalVisible] = useState(false);

  useEffect(() => {
    fetchRestaurants();
  }, []);

  const fetchRestaurants = async () => {
    try {
      const response = await fetch(`${Config.API_URL}/restaurants`);
      if (response.ok) {
        const data = await response.json();
       // console.log(data);
        setRestaurants(data);
      } else {
        console.error('Error fetching restaurants:', response.status);
      }
    } catch (error) {
      console.error('Error fetching restaurants:', error.message);
    }
  };

  const handleLogout = () => {
    setLogoutPopupVisible(false);
    navigation.navigate('Login');
  };

  const handleSearchPress = () => {
    setSearchModalVisible(true);
  };

  const handleLogoutIconPress = () => {
    setLogoutPopupVisible(true);
  };

  const handleChatPress = () => {
     navigation.navigate('ChatScreen', { customerId: 'vreddy01@gmail.com' });
  };

  const handleOrdersPress = () => {
    //console.log(ownerEmail+'navigating  history');
    navigation.navigate('OrderHistoryPage', { customerId: ownerEmail });
  };

  const renderRestaurantItem = ({ item }) => (
    <TouchableOpacity
      style={styles.gridItem}
      onPress={() => handleRestaurantPress(item)}
    >
      <Text style={styles.itemName}>{item.name}</Text>
      {/* Assuming itemPrice is present in your restaurant data */}
      <Text style={styles.itemPrice}>{item.itemPrice}</Text>
    </TouchableOpacity>
  );

  const handleRestaurantPress = (restaurant) => {
    // Navigate to the ItemsList screen with the selected restaurant's email
    //console.log('cust_home'+ownerEmail);
    //console.log(restaurant.username);
    navigation.navigate('ItemsList', { restaurantEmail: restaurant.username, User: ownerEmail });
  };

  const filteredRestaurants = restaurants.filter(
    (restaurant) =>
      restaurant.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.iconContainer} onPress={handleSearchPress}>
          <FontAwesome name="search" size={24} color="black" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.logoutIconContainer} onPress={handleLogoutIconPress}>
          <FontAwesome name="sign-out" size={24} color="black" />
        </TouchableOpacity>
        <TextInput
          style={styles.searchInput}
          placeholder="Search Restuarants..."
          value={searchQuery}
          onChangeText={(text) => setSearchQuery(text)}
        />
      </View>

      <View style={styles.bannerWrapper}>
        <Swiper showsPagination={false} autoplay>
          <Image source={require('../paths/banner1.jpg')} style={styles.bannerImage} resizeMode="cover" />
          <Image source={require('../paths/banner2.jpg')} style={styles.bannerImage} resizeMode="cover" />
        </Swiper>
      </View>

      <FlatList
        data={filteredRestaurants}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderRestaurantItem}
        numColumns={2}
        style={styles.gridList}
      />
      <View style={styles.bottomMenu}>
        <TouchableOpacity style={styles.bottomIcon} onPress={handleChatPress}>
          <FontAwesome name="comments" size={24} color="white" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.bottomIcon} onPress={handleOrdersPress}>
          <FontAwesome name="history" size={24} color="white" />
        </TouchableOpacity>
      </View>

      <Modal isVisible={logoutPopupVisible} onBackdropPress={() => setLogoutPopupVisible(false)}>
        <View style={styles.logoutPopup}>
          <Text>Are you sure you want to logout?</Text>
          <View style={styles.logoutButtons}>
            <TouchableOpacity onPress={() => setLogoutPopupVisible(false)}>
              <Text>No</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleLogout()}>
              <Text>Yes</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal isVisible={searchModalVisible} onBackdropPress={() => setSearchModalVisible(false)}>
        <View style={styles.searchModal}>
          <Text>This is the search modal</Text>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  bannerWrapper: {
    height: 150,
  },
  bannerImage: {
    flex: 1,
    borderRadius: 8,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#add8e6',
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    fontSize: 16,
  },
  iconContainer: {
    padding: 8,
    paddingTop:25,
  },
  gridList: {
    flex: 1,
    padding: 16,
  },
  gridItem: {
    flex: 1,
    backgroundColor: '#eee',
    padding: 16,
    margin: 8,
    borderRadius: 8,
  },
  itemName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  itemPrice: {
    fontSize: 16,
    color: 'gray',
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  quantityButton: {
    backgroundColor: '#007bff',
    padding: 8,
    borderRadius: 4,
  },
  quantityText: {
    marginHorizontal: 8,
    fontSize: 16,
  },
  bottomMenu: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#add8e6',
  },
  bottomIcon: {
    backgroundColor: 'transparent',
    padding: 8,
    borderRadius: 8,
  },
  
  logoutPopup: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
  },
  logoutPrompt: {
    fontSize: 18, // Adjust the font size as needed
    color: 'white', // Set the text color to white
    marginBottom: 10, // Add some spacing at the bottom
  },
  logoutButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
  },
  logoutIconContainer: {
    position: 'absolute',
    top: 16,
    paddingTop:25,
    padding:8,
    right: 16,
  },
  logoutPopup: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
  },
  logoutButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
  },
});

export default UserProfile;
