import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, TextInput, StyleSheet, Image } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import Swiper from 'react-native-swiper';
import Config from '../api/urlConfig';
import Modal from 'react-native-modal';

const ItemsList = ({ route, navigation }) => {
  const { restaurantEmail, User } = route.params;
  const [items, setItems] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItems, setSelectedItems] = useState({});
  const [logoutPopupVisible, setLogoutPopupVisible] = useState(false);
  const [searchModalVisible, setSearchModalVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null); // Track selected item for showing details

  useEffect(() => {
    fetchItemsFromDatabase();
  }, [restaurantEmail]);

  const fetchItemsFromDatabase = async () => {
    try {
      const response = await fetch(`${Config.API_URL}/api/getItems?ownerEmail=${restaurantEmail}`);
      if (response.ok) {
        const data = await response.json();
        // Initialize selectedItems state with 0 quantity for each item
        const initialSelectedItems = {};
        data.forEach(item => {
          initialSelectedItems[item.id] = 0;
        });
        setSelectedItems(initialSelectedItems);
        setItems(data);
      } else {
        console.error('Error fetching items:', response.status);
      }
    } catch (error) {
      console.error('Error fetching items:', error.message);
    }
  };

  const handleCartPress = () => {
    const selectedItemsArray = Object.keys(selectedItems).filter((itemId) => selectedItems[itemId] > 0);
    if (selectedItemsArray.length > 0) {
      navigation.navigate('Cart', { selectedItems, items, User, restaurantEmail });
    } else {
      console.log('No items selected');
    }
  };

  const handleLogout = () => {
    setLogoutPopupVisible(false);
    navigation.navigate('Login');
  };

  const handleSearchPress = () => {
    setSearchModalVisible(true);
  };

  const handleLogoutIconPress = () => {
    setLogoutPopupVisible(true);
  };

  const handleChatPress = () => {
    // navigation.navigate('ChatScreen', { customerId: 'vreddy01@gmail.com' });
  };

  const handleOrdersPress = () => {
    navigation.navigate('OrderHistoryPage', { customerId: User });
  };

  const handleQuantityChange = (itemId, quantity) => {
    setSelectedItems((prevSelectedItems) => ({
      ...prevSelectedItems,
      [itemId]: quantity,
    }));
  };

  const handleItemPress = (item) => {
    setSelectedItem(item);
  };

  const renderGridItem = ({ item }) => (
    <TouchableOpacity onPress={() => handleItemPress(item)}>
      <View style={styles.gridItem}>
        <Text style={styles.itemName}>{item.itemName}</Text>
        <Text style={styles.itemPrice}>{item.itemPrice}</Text>

        <View style={styles.quantityContainer}>
          <TouchableOpacity
            style={styles.quantityButton}
            onPress={() => handleQuantityChange(item.id, selectedItems[item.id] > 0 ? selectedItems[item.id] - 1 : 0)}
          >
            <FontAwesome name="minus" size={16} color="white" />
          </TouchableOpacity>
          <Text style={styles.quantityText}>{selectedItems[item.id]}</Text>
          <TouchableOpacity
            style={styles.quantityButton}
            onPress={() => handleQuantityChange(item.id, selectedItems[item.id] + 1)}
          >
            <FontAwesome name="plus" size={16} color="white" />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );

  const filteredItems = items.filter(
    (item) =>
      item.itemName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.itemPrice.toString().includes(searchQuery)
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.iconContainer} onPress={handleSearchPress}>
          <FontAwesome name="search" size={24} color="black" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.logoutIconContainer} onPress={handleLogoutIconPress}>
          <FontAwesome name="sign-out" size={24} color="black" />
        </TouchableOpacity>
        <TextInput
          style={styles.searchInput}
          placeholder="Search items..."
          value={searchQuery}
          onChangeText={(text) => setSearchQuery(text)}
        />
      </View>

      <View style={styles.bannerWrapper}>
        <Swiper showsPagination={false} autoplay>
          <Image source={require('../paths/banner1.jpg')} style={styles.bannerImage} resizeMode="cover" />
          <Image source={require('../paths/banner2.jpg')} style={styles.bannerImage} resizeMode="cover" />
        </Swiper>
      </View>

      <FlatList
        data={filteredItems}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderGridItem}
        numColumns={2}
        style={styles.gridList}
      />

      <View style={styles.bottomMenu}>
        <TouchableOpacity style={styles.bottomIcon} onPress={handleChatPress}>
          <FontAwesome name="comments" size={24} color="white" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.bottomIcon} onPress={handleOrdersPress}>
          <FontAwesome name="history" size={24} color="white" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.bottomIcon} onPress={handleCartPress}>
          <FontAwesome name="shopping-cart" size={24} color="white" />
        </TouchableOpacity>
      </View>

      <Modal isVisible={logoutPopupVisible} onBackdropPress={() => setLogoutPopupVisible(false)}>
        <View style={styles.logoutPopup}>
          <Text>Are you sure you want to logout?</Text>
          <View style={styles.logoutButtons}>
            <TouchableOpacity onPress={() => setLogoutPopupVisible(false)}>
              <Text>No</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleLogout()}>
              <Text>Yes</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal isVisible={searchModalVisible} onBackdropPress={() => setSearchModalVisible(false)}>
        <View style={styles.searchModal}>
          <Text>This is the search modal</Text>
        </View>
      </Modal>

      {/* Modal for showing item details */}
      <Modal isVisible={selectedItem !== null} onBackdropPress={() => setSelectedItem(null)}>
        <View style={styles.itemDetailModal}>
          <Text style={styles.itemName}>{selectedItem?.itemName}</Text>
          <Text style={styles.itemPrice}>{selectedItem?.itemPrice}</Text>
          <Text style={styles.itemDescription}>{selectedItem?.itemDescription}</Text>
          {/* Add more details here as needed */}
          <TouchableOpacity onPress={() => setSelectedItem(null)}>
            <Text>Close</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  bannerWrapper: {
    height: 150,
  },
  bannerImage: {
    flex: 1,
    borderRadius: 8,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#add8e6',
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    fontSize: 16,
  },
  iconContainer: {
    padding: 8,
    paddingTop: 25,
  },
  gridList: {
    flex: 1,
    padding: 16,
  },
  gridItem: {
    flex: 1,
    backgroundColor: '#eee',
    padding: 16,
    margin: 8,
    borderRadius: 8,
  },
  itemName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  itemPrice: {
    fontSize: 16,
    color: 'gray',
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  quantityButton: {
    backgroundColor: '#007bff',
    padding: 8,
    borderRadius: 4,
  },
  quantityText: {
    marginHorizontal: 8,
    fontSize: 16,
  },
  bottomMenu: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#add8e6',
  },
  bottomIcon: {
    backgroundColor: 'transparent',
    padding: 8,
    borderRadius: 8,
  },
  logoutIconContainer: {
    position: 'absolute',
    top: 16,
    paddingTop: 25,
    padding: 8,
    right: 16,
  },
  logoutPopup: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
  },
  logoutButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
  },
  itemDetailModal: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
  },
});

export default ItemsList;
