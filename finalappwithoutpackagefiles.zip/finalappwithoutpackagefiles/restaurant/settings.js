import React, { useState, useEffect } from 'react';

import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import axios from 'axios'; // Ensure this path is correct relative to your file structure


const SettingsScreen = () => {
    const [username, setUsername] = useState('');

  useEffect(() => {
    // Fetch username from the backend when the component mounts
    axios.get('http://192.168.0.103:3000/getUserDetails')
      .then(response => {
        setUsername(response.data.username);
      })
      .catch(error => {
        console.error('Error fetching username:', error);
      });
  }, []); // The empty dependency array ensures this effect runs only once on mount

  const [restaurantName, setRestaurantName] = useState('');
  const [location, setLocation] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const updateRestaurantDetails = () => {
    // Logic to update restaurant details using the backend API
    axios.put('http://192.168.0.103:3000/updateRestaurant', { restaurantName, location })
      .then(response => {
        console.log('Restaurant details updated:', response.data);
      })
      .catch(error => {
        console.error('Error updating restaurant details:', error);
        if (error.response) {
          console.error('Response data:', error.response.data);
          console.error('Response status:', error.response.status);
          console.error('Response headers:', error.response.headers);
        } else if (error.request) {
          console.error('Request made but no response received:', error.request);
        } else {
          console.error('Error setting up the request:', error.message);
        }
      });
  };
  
  
  const changePassword = () => {
    axios.put('http://192.168.0.103:3000/changePassword', { currentPassword, newPassword })
      .then(response => {
        console.log('Password changed:', response.data);
        // Show a success message or trigger any UI updates needed
      })
      .catch(error => {
        if (error.response) {
          console.error('Error changing password:', error.response.data);
          // Show an error message based on error.response.data
        } else if (error.request) {
          console.error('Request made but no response received:', error.request);
          // Show an error message for no response
        } else {
          console.error('Error setting up the request:', error.message);
          // Show a generic error message for other issues
        }
      });
  };
  

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Update Restaurant Details</Text>
      <Text style={styles.title}>User Profile</Text>
      <Text style={styles.text}>Username: {username}</Text>
      <TextInput
        style={styles.input}
        placeholder="Restaurant Name"
        value={restaurantName}
        onChangeText={text => setRestaurantName(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Location"
        value={location}
        onChangeText={text => setLocation(text)}
      />
      <TouchableOpacity style={styles.button} onPress={updateRestaurantDetails}>
        <Text style={styles.buttonText}>Update Details</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Change Password</Text>
      <TextInput
        style={styles.input}
        placeholder="Current Password"
        secureTextEntry
        value={currentPassword}
        onChangeText={text => setCurrentPassword(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="New Password"
        secureTextEntry
        value={newPassword}
        onChangeText={text => setNewPassword(text)}
      />
      <TouchableOpacity style={styles.button} onPress={changePassword}>
        <Text style={styles.buttonText}>Change Password</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  button: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
    width: '50%',
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default SettingsScreen;
