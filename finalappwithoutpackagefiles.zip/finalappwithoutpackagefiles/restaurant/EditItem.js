import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import Config from '../api/urlConfig';

const EditItem = ({ route, navigation }) => {
  const { item } = route.params;
  const [itemName, setItemName] = useState(item.itemName);
  const [itemDescription, setItemDescription] = useState(item.itemDescription);
  const [itemPrice, setItemPrice] = useState(item.itemPrice);

  const handleSaveItem = async () => {
    try {
      // Prepare the updated item object
      const updatedItem = {
        id: item.id,
        itemName: itemName,
        itemDescription: itemDescription,
        itemPrice: itemPrice
      };
  
      // Send a request to update the item on the server
      const response = await fetch(`${Config.API_URL}/api/updateItem`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedItem),
      });
  
      if (response.ok) {
        // If the item was updated successfully, navigate back to the previous screen
        navigation.goBack();
      } else {
        console.error('Failed to update item');
        // Handle error accordingly (e.g., display error message to the user)
      }
    } catch (error) {
      console.error('Error updating item:', error);
      // Handle error accordingly (e.g., display error message to the user)
    }
  };

  return (
    <View>
      <TextInput
        style={styles.input}
        value={itemName}
        onChangeText={text => setItemName(text)}
        placeholder="Item Name"
      />
      <TextInput
        style={styles.input}
        value={itemDescription}
        onChangeText={text => setItemDescription(text)}
        placeholder="Item Description"
      />
      <TextInput
        style={styles.input}
        value={itemPrice}
        onChangeText={text => setItemPrice(text)}
        placeholder="Item Price"
        keyboardType="numeric"
      />
      <TouchableOpacity onPress={handleSaveItem}>
        <Text style={styles.saveButton}>Save</Text>
      </TouchableOpacity>
    </View>
  );
};

// Define styles object
const styles = StyleSheet.create({
  input: {
    borderWidth: 1,
    borderColor: 'gray',
    padding: 10,
    marginBottom: 10,
  },
  saveButton: {
    backgroundColor: 'blue',
    color: 'white',
    textAlign: 'center',
    padding: 10,
    borderRadius: 5,
  },
});

export default EditItem;
