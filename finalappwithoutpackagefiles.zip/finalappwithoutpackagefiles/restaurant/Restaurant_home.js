import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, TextInput, StyleSheet, Image, ScrollView } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import Swiper from 'react-native-swiper';
import Config from '../api/urlConfig';
import Modal from 'react-native-modal';

const RestaurantHome = ({ route, navigation }) => {
  const { ownerEmail } = route.params;
  const [restaurants, setRestaurants] = useState([]); // State to store restaurant data
  const [orders, setOrders] = useState([]); // State to store orders data
  const [searchQuery, setSearchQuery] = useState('');
  const [logoutPopupVisible, setLogoutPopupVisible] = useState(false);
  const [searchModalVisible, setSearchModalVisible] = useState(false);
  const [orderDetailsVisible, setOrderDetailsVisible] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null); // State to store the selected order

  useEffect(() => {
    fetchOrdersForRestaurant();
  }, []);
  
  const fetchOrdersForRestaurant = async () => {
    try {
      const response = await fetch(`${Config.API_URL}/api/orders/${ownerEmail}`);
      if (response.ok) {
        const data = await response.json();
        const ordersData = data.map((order) => ({
          ...order,
          items: JSON.parse(order.items),
        }));
        setOrders(ordersData);
      } else {
        console.error('Error fetching orders:', response.status);
      }
    } catch (error) {
      console.error('Error fetching orders:', error.message);
    }
  };

  const handleUpdateStatus = async () => {
    try {
      const response = await fetch(`${Config.API_URL}/api/orders/${selectedOrder.id}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: 'processed' }), // Assuming the new status is fixed
      });
  
      if (!response.ok) {
        throw new Error('Failed to update order status');
      }
  
      // Update the status of the selected order locally
      const updatedOrder = { ...selectedOrder, status: 'processing' };
      setSelectedOrder(updatedOrder);
      // Close the modal
      setOrderDetailsVisible(false);
    } catch (error) {
      console.error('Error updating order status:', error);
      // Handle error
    }
  };
  
  const handleLogout = () => {
    setLogoutPopupVisible(false);
    navigation.navigate('Login');
  };

  const handleSearchPress = () => {
    setSearchModalVisible(true);
  };

  const handleLogoutIconPress = () => {
    setLogoutPopupVisible(true);
  };

  const handleChatPress = () => {
    navigation.navigate('screen', { customerId: 'vreddy01@gmail.com' });
  };

  const handleOrdersPress = () => {
    navigation.navigate('ResturantOrderHistoryPage', { customerId: ownerEmail });
  };

  const handleOrderPress = (order) => {
    setSelectedOrder(order);
    setOrderDetailsVisible(true);
  };

  const handleItemListPress = () => {
    navigation.navigate('ResturantItemList', { restaurantEmail: ownerEmail });
  };

  const handleRestaurantPress = (restaurant) => {
    console.log('cust_home' + ownerEmail);
    console.log(restaurant.username);
    navigation.navigate('ItemsList', { restaurantEmail: restaurant.username, User: ownerEmail });
  };

  const filteredRestaurants = restaurants.filter(
    (restaurant) => restaurant.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.iconContainer} onPress={handleSearchPress}>
          <FontAwesome name="search" size={24} color="black" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.logoutIconContainer} onPress={handleLogoutIconPress}>
          <FontAwesome name="sign-out" size={24} color="black" />
        </TouchableOpacity>
        <TextInput
          style={styles.searchInput}
          placeholder="Search Restaurants..."
          value={searchQuery}
          onChangeText={(text) => setSearchQuery(text)}
        />
      </View>

      <View style={styles.bannerWrapper}>
        <Swiper showsPagination={false} autoplay>
          <Image source={require('../paths/banner1.jpg')} style={styles.bannerImage} resizeMode="cover" />
          <Image source={require('../paths/banner2.jpg')} style={styles.bannerImage} resizeMode="cover" />
        </Swiper>
      </View>

      <View style={styles.sectionContainer}>
        <Text style={styles.title}>Orders</Text>
        <FlatList
          data={orders}
          keyExtractor={(item) => (item.id ? item.id.toString() : null)}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.orderItem} onPress={() => handleOrderPress(item)}>
              <View style={{ flexDirection: 'row' }}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.orderItemText}>{`Order #${item.id}`}</Text>
                  <Text style={styles.orderItemText}>{`Customer Name: ${item.name}`}</Text>
                  <Text style={styles.orderItemText}>{`Cost: ${item.totalAmount}`}</Text>
                  {item.items.map((orderItem, index) => (
                    <View key={index}>
                      <Text style={styles.orderItemText}>{`Item id: ${orderItem.itemId}`}</Text>
                      <Text style={styles.orderItemText}>{`Quantity: ${orderItem.quantity}`}</Text>
                    </View>
                  ))}
                  <Text style={styles.orderItemText}>{`Status: ${item.status}`}</Text>
                </View>
                <Image source={require('../assets/logo.png')} style={styles.imageStyle} />
              </View>
            </TouchableOpacity>
          )}
        />
      </View>

      <Modal 
        isVisible={orderDetailsVisible} 
        onBackdropPress={() => setOrderDetailsVisible(false)}
      >
        <View style={styles.modalContainer}>
          {selectedOrder && (
            <ScrollView contentContainerStyle={styles.scrollView}>
              <View style={styles.orderDetailBox}>
                <Text style={styles.orderDetailText}>Order #{selectedOrder.id}</Text>
              </View>
              <View style={styles.orderDetailBox}>
                <Text style={styles.orderDetailText}>Customer Name: {selectedOrder.id}</Text>
              </View>
              <View style={styles.orderDetailBox}>
                <Text style={styles.orderDetailText}>Cost: {selectedOrder.totalAmount}</Text>
              </View>
              <View style={styles.orderDetailBox}>
                <Text style={styles.orderDetailText}>Status: {selectedOrder.status}</Text>
              </View>
              <Text style={styles.orderDetailText}>Items:</Text>
              {selectedOrder.items.map((item, index) => (
                <View key={index} style={styles.orderDetailBox}>
                  <Text style={styles.orderDetailText}>{`- Item ID: ${item.itemId}, Quantity: ${item.quantity}`}</Text>
                </View>
              ))}
            </ScrollView>
          )}
          <TouchableOpacity onPress={() => setOrderDetailsVisible(false)} style={[styles.button, styles.closeButton]}>
            <Text style={styles.buttonText}>Close</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleUpdateStatus} style={[styles.button, styles.updateStatusButton]}>
            <Text style={styles.buttonText}>Update Status</Text>
          </TouchableOpacity>
          <Image source={require('../assets/logo.png')} style={styles.image} />
        </View>
      </Modal>

      <View style={styles.bottomMenu}>
        <TouchableOpacity style={styles.bottomIcon} onPress={handleChatPress}>
          <FontAwesome name="comments" size={24} color="white" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.bottomIcon} onPress={handleOrdersPress}>
          <FontAwesome name="history" size={24} color="white" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.bottomIcon} onPress={handleItemListPress}>
          <FontAwesome name="list" size={24} color="white" />
        </TouchableOpacity>
      </View>

      <Modal isVisible={logoutPopupVisible} onBackdropPress={() => setLogoutPopupVisible(false)}>
        <View style={styles.logoutPopup}>
          <Text>Are you sure you want to logout?</Text>
          <View style={styles.logoutButtons}>
            <TouchableOpacity onPress={() => setLogoutPopupVisible(false)}>
              <Text>No</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleLogout()}>
              <Text>Yes</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal isVisible={searchModalVisible} onBackdropPress={() => setSearchModalVisible(false)}>
        <View style={styles.searchModal}>
          <Text>This is the search modal</Text>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 20,
    backgroundColor: '#add8e6',
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    marginRight:40,
    fontSize: 16,
    paddingVertical: 10,
    paddingHorizontal: 12,
    backgroundColor: '#fff',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  iconContainer: {
    paddingHorizontal: 16,
    paddingVertical: 20,
    alignItems: 'center',
  },
  orderItem: {
    backgroundColor: '#f5f5f5',
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#ddd',
    shadowColor: '#000', 
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  orderItemText: {
    fontSize: 16,
    color: '#333',
    fontWeight: 'bold',
    marginBottom: 8,
  },
  bottomMenu: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    backgroundColor: '#add8e6',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: -3,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  bottomIcon: {
    backgroundColor: 'transparent',
    padding: 8,
    borderRadius: 8,
  },
  logoutPopup: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
  },
  logoutButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
    color: 'black',
  },
  logoutIconContainer: {
    position: 'absolute',
    top: 16,
    paddingTop: 25,
    padding: 8,
    right: 16,
  },
  searchModal: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
  },
  bannerWrapper: {
    height: 200,
  },
  bannerImage: {
    width: '100%',
    height: '100%',
  },
  sectionContainer: {
    marginVertical: 10,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    paddingHorizontal: 16,
  },
  imageStyle: {
    width: 100,
    height: 150,
    resizeMode: 'contain', 
    marginLeft: 10, 
  },
  modalContainer: {
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    borderRadius:10,
    paddingTop: 20,
    width:'90%',
    paddingBottom: 10,
    height:300,
    margin: 20,
  },
  scrollView: {
    flexGrow: 1,
  },
  orderDetailText: {
    fontSize: 18,
    marginBottom: 10,
  },
  button: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 10,
    marginTop: 10,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 16,
    color: '#fff',
  },
  closeButton: {
    backgroundColor: 'red',
  },
  updateStatusButton: {
    backgroundColor: 'green',
  },
  image: {
    position: 'absolute',
    top: 2,
    right: 20,
    width: 100, 
    height: 100, 
    resizeMode: 'contain', 
  },
});

export default RestaurantHome;
