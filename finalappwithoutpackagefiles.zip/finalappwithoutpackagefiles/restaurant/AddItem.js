import React, { useState } from 'react';
import { View, Text, TextInput, Button, Image, StyleSheet } from 'react-native';
import ImagePicker from 'react-native-image-picker';
import Config from '../api/urlConfig';

//const ownerEmail = 'vreddy01@gmail.com';

const AddItem = ({ navigation, route }) => {
  const { ownerEmail } = route.params;
  const [itemInput, setItemInput] = useState({
    itemName: '',
    itemPrice: '',
    itemDescription: '',
    itemImage: null,
  });

  const handleImagePicker = () => {
    const options = {
      title: 'Select Image',
      storageOptions: {
        skipBackup: true,
        path: 'images',
      },
    };

    ImagePicker.showImagePicker(options, (response) => {
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else {
        // Set the selected image in state
        setItemInput({ ...itemInput, itemImage: `data:image/jpeg;base64,${response.data}` });
      }
    });
  };

  const saveItem = async () => {
    try {
      // Make sure to replace this URL with your actual server endpoint
      const apiUrl = `${Config.API_URL}/api/addItem`;

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          itemName: itemInput.itemName,
          itemPrice: itemInput.itemPrice,
          itemDescription: itemInput.itemDescription,
          itemImage: itemInput.itemImage, // Assuming itemImage is a base64-encoded string
          ownerEmail: ownerEmail, // Include the owner's email in the payload
        }),
      });

      if (response.ok) {
        console.log('Item added successfully');
        // Navigate back to Restaurant_home after saving
        navigation.navigate('Restaurant_home');
      } else {
        console.error('Error adding item:', response.status);
        // Handle error scenarios
      }
    } catch (error) {
      console.error('Error adding item:', error.message);
      // Handle error scenarios
    }
  };

  return (
    <View style={styles.container}>
      <Text>Add Item</Text>
      <TextInput
        style={styles.input}
        placeholder="Item Name"
        value={itemInput.itemName}
        onChangeText={(text) => setItemInput({ ...itemInput, itemName: text })}
      />
      <TextInput
        style={styles.input}
        placeholder="Item Price"
        value={itemInput.itemPrice}
        onChangeText={(text) => setItemInput({ ...itemInput, itemPrice: text })}
      />
      <TextInput
        style={styles.input}
        placeholder="Item Description"
        value={itemInput.itemDescription}
        onChangeText={(text) => setItemInput({ ...itemInput, itemDescription: text })}
      />
      <Button title="Select Image" onPress={handleImagePicker} />
      {/* Display selected image */}
      {itemInput.itemImage && <Image source={{ uri: itemInput.itemImage }} style={styles.image} />}
      <Button title="Save" onPress={saveItem} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    borderRadius: 8,
    paddingLeft: 10,
    width: '100%',
  },
  image: {
    width: 100,
    height: 100,
    resizeMode: 'cover',
    borderRadius: 8,
    marginTop: 10,
  },
});

export default AddItem;
