import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { Card } from 'react-native-elements';
import Config from '../api/urlConfig';

const RestaurantOrderHistoryPage = ({ route }) => {
  const { customerId } = route.params;
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchOrdersForCustomer();
  }, []);

  const fetchOrdersForCustomer = async () => {
    try {
      const response = await fetch(`${Config.API_URL}/api/ses/${customerId}`);
      if (response.ok) {
        const data = await response.json();
        const ordersData = data.map((order) => ({
          ...order,
          items: JSON.parse(order.items),
        }));
        setOrders(ordersData);
      } else {
        console.error('Error fetching orders:', response.status);
      }
    } catch (error) {
      console.error('Error fetching orders:', error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Order History</Text>
      <FlatList
        data={orders}
        keyExtractor={(item) => (item.id ? item.id.toString() : null)}
        renderItem={({ item }) => (
          <Card containerStyle={styles.orderItem}>
            <Text style={styles.orderItemText}>{`Order #${item.id}`}</Text>
            <Text style={styles.orderItemText}>{`Cost: ${item.totalAmount}`}</Text>
            {item.items.map((orderItem, index) => (
              <View key={index} style={styles.productItem}>
                <Text style={styles.orderItemText}>{`Item ID: ${orderItem.itemId} `}</Text>
                <Text style={styles.orderItemText}>{`Quantity: ${orderItem.quantity}`}</Text>
              </View>
            ))}
            <Text style={styles.orderItemStatus}>{`Status: ${item.status}`}</Text>
          </Card>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  orderItem: {
    backgroundColor: '#f9f9f9',
    marginBottom: 20,
    borderRadius: 12,
    borderWidth: 0, // Remove border
    elevation: 5, // Add shadow for depth effect
  },
  orderItemText: {
    fontSize: 16,
    color: '#555',
    marginBottom: 8,
  },
  productItem: {
    marginLeft: 20, // Adjust indentation for product items
  },
  orderItemStatus: {
    marginTop: 10,
    fontSize: 16,
    color: '#007bff',
    fontWeight: 'bold',
  },
});

export default RestaurantOrderHistoryPage;
