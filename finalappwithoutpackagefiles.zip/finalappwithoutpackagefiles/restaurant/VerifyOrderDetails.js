// VerifyOrderDetails.js

import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import Config from '../api/urlConfig';

const VerifyOrderDetails = ({ route, navigation }) => {
  const { orderId } = route.params;
  const [orderDetails, setOrderDetails] = useState(null);

  useEffect(() => {
    fetchOrderDetails();
  }, []);

  const fetchOrderDetails = async () => {
    try {
      const response = await fetch(`${Config.API_URL}/api/orders/${orderId}`);
      if (response.ok) {
        const data = await response.json();
        console.log("Order Details:", data); // Log the response data
        setOrderDetails(data);
      } else {
        console.error('Error fetching order details:', response.status);
      }
    } catch (error) {
      console.error('Error fetching order details:', error.message);
    }
  };
  

  const handleProcessOrder = async () => {
    try {
      // Update order status to 'processed' in the database
      const response = await fetch(`${Config.API_URL}/api/orders/${orderId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: 'processed' }),
      });
      if (response.ok) {
        // Order processed successfully, navigate back to the previous screen
        navigation.goBack();
      } else {
        console.error('Error processing order:', response.status);
      }
    } catch (error) {
      console.error('Error processing order:', error.message);
    }
  };

  if (!orderDetails) {
    return (
      <View style={styles.container}>
        <Text>Loading...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Render order details here */}
      <Text>Order ID: {orderDetails.id}</Text>
      <Text>Status: {orderDetails.status}</Text>
      {/* Add more order details as needed */}
      
      {/* Button to process the order */}
      <TouchableOpacity style={styles.processButton} onPress={handleProcessOrder}>
        <Text style={styles.buttonText}>Process Order</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  processButton: {
    backgroundColor: 'green',
    padding: 10,
    marginTop: 20,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default VerifyOrderDetails;
