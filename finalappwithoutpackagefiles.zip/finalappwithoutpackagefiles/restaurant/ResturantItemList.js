import React, { useState, useEffect } from 'react';
import Config from '../api/urlConfig';
import { View, Text, TouchableOpacity, FlatList, TextInput, StyleSheet, Alert } from 'react-native';

const RestaurantItemList = ({ navigation, route }) => {
  const { restaurantEmail } = route.params;
  const [items, setItems] = useState([]); 
  const [itemName, setItemName] = useState('');
  const [itemPrice, setItemPrice] = useState('');
  const [itemDescription, setItemDescription] = useState('');

  useEffect(() => {
    fetchItems();
  }, []);
  const handleAddItem = async () => {
    try {
      const response = await fetch(`${Config.API_URL}/api/items`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          itemName: itemName,
          itemPrice: itemPrice,
          itemDescription:itemDescription,
          ownerEmail: restaurantEmail,
        }),
      });

      if (response.ok) {
        // Item added successfully, fetch updated items
        fetchItems();
        // Clear input fields
        setItemName('');
        setItemPrice('');
        setItemDescription('');
      } else {
        console.error('Error adding item:', response.status);
      }
    } catch (error) {
      console.error('Error adding item:', error.message);
    }
  };
  const handleDeleteItem = async (itemId) => {
    Alert.alert(
      'Confirm Deletion',
      'Are you sure you want to delete this item?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          onPress: async () => {
            try {
              const response = await fetch(`${Config.API_URL}/api/items/${itemId}`, {
                method: 'DELETE',
              });
          
              if (response.ok) {
                fetchItems(); // Fetch items again after deletion
              } else {
                console.error('Error deleting item:', response.status);
              }
            } catch (error) {
              console.error('Error deleting item:', error.message);
            }
          },
          style: 'destructive',
        },
      ],
      { cancelable: false }
    );
  };
  
  const fetchItems = async () => {
    try {
      const response = await fetch(`${Config.API_URL}/api/items/${restaurantEmail}`);
      if (response.ok) {
        const data = await response.json();
        setItems(data);
      } else {
        console.error('Error fetching items:', response.status);
      }
    } catch (error) {
      console.error('Error fetching items:', error.message);
    }
  };

  const renderItem = ({ item }) => {
    return (
      <View style={styles.item}>
          <Text style={styles.itemName}>{item.itemName}</Text>
          <Text style={styles.itemDescription} numberOfLines={2}>{item.itemDescription}</Text>
          <Text style={styles.itemPrice}>{item.itemPrice}</Text>  
        <View style={styles.editDeleteButtons}>
          <TouchableOpacity onPress={() => navigation.navigate('EditItem', { item })}>
            <Text style={styles.editDeleteText}>Edit</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleDeleteItem(item.id)}>
            <Text style={styles.editDeleteText}>Delete</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Item List</Text>
      <FlatList
        data={items}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderItem}
      />
      <View style={styles.addItemContainer}>
        <TextInput
          style={styles.input}
          placeholder="Item Name"
          value={itemName}
          onChangeText={(text) => setItemName(text)}
        />
        <TextInput
          style={styles.input}
          placeholder="Description"
          value={itemDescription}
          onChangeText={(text) => setItemDescription(text)}
        />
        <TextInput
          style={styles.input}
          placeholder="Item Price"
          value={itemPrice}
          onChangeText={(text) => setItemPrice(text)}
        />
        <TouchableOpacity style={styles.addButton} onPress={handleAddItem}>
          <Text style={styles.addButtonText}>Add Item</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
    color: '#333',
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
    marginBottom: 16,
    borderRadius: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  itemName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  itemPrice: {
    fontSize: 16,
    color: '#555',
  },
  editDeleteButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  editDeleteText: {
    marginLeft: 16,
    color: '#007bff',
    fontSize: 16,
  },
  addItemContainer: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  input: {
    height: 48,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 16,
    borderRadius: 8,
    fontSize: 16,
    color: '#333',
  },
  addButton: {
    backgroundColor: '#28a745',
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  itemDescription: {
    flex: 1, // This allows the itemDescription to take up remaining space
    fontSize: 16,
    color: '#555',
    marginLeft: 8, // Adjust spacing between itemName and itemDescription if needed
  },
  addButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default RestaurantItemList;
