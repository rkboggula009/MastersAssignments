import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Dimensions } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { Card, Button, ListItem, Avatar, Icon } from 'react-native-elements';
import * as Location from 'expo-location';
import MapViewDirections from 'react-native-maps-directions';

const GOOGLE_MAPS_API_KEY = 'AIzaSyC1EcOr2ydSTPzpGB1F7dJwwbt5AywIUt0'; // Replace with your Google Maps API key

const RiderHomeScreen = ({ navigation }) => {
  const [currentLocation, setCurrentLocation] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [pendingOrders, setPendingOrders] = useState([
    { id: '1', customerName: 'Customer 1', address: 'Banjara Hills, Hyderabad', lat: 17.4151, lng: 78.4341 },
    { id: '2', customerName: 'Customer 2', address: 'Hitech City, Hyderabad', lat: 17.4497, lng: 78.3865 },
    // Add more orders in Hyderabad as needed
  ]);

  useEffect(() => {
    const fetchLocation = async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.error('Permission to access location was denied');
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      setCurrentLocation(location.coords);
    };

    fetchLocation();
  }, []);

  const onOrderPress = (order) => {
    setSelectedOrder(order);
  };

  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        initialRegion={{
          latitude: 17.3850, // Hyderabad coordinates
          longitude: 78.4867,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
        region={currentLocation ? {
          latitude: currentLocation.latitude,
          longitude: currentLocation.longitude,
          latitudeDelta: 0.005,
          longitudeDelta: 0.005,
        } : undefined}
      >
        {currentLocation && (
          <Marker
            coordinate={currentLocation}
            title="Your Location"
            image={require('../assets/rider.png')}
            style={{ width: 1, height: 2 }} // Set your desired size here
            resizeMode="contain" // Replace with your rider icon
          />
        )}

        {selectedOrder && (
          <MapViewDirections
            origin={currentLocation}
            destination={{ latitude: selectedOrder.lat, longitude: selectedOrder.lng }}
            apikey={GOOGLE_MAPS_API_KEY}
            strokeWidth={4}
            strokeColor="blue"
          />
        )}

        {pendingOrders.map((order) => (
          <Marker
            key={order.id}
            coordinate={{ latitude: order.lat, longitude: order.lng }}
            title={order.customerName}
            description={order.address}
            onPress={() => onOrderPress(order)}
          />
        ))}
      </MapView>

      <Card containerStyle={styles.card}>
        <Text style={styles.cardTitle}>Pending Orders</Text>
        <FlatList
          data={pendingOrders}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => onOrderPress(item)}>
              <ListItem bottomDivider>
                <Avatar rounded source={{ uri: 'https://placeimg.com/140/140/any' }} size="medium" />
                <ListItem.Content>
                  <ListItem.Title>{item.customerName}</ListItem.Title>
                  <ListItem.Subtitle>{item.address}</ListItem.Subtitle>
                </ListItem.Content>
                <Icon name="chevron-right" type="entypo" />
              </ListItem>
            </TouchableOpacity>
          )}
        />
      </Card>

      <View style={styles.profile}>
        <Avatar rounded source={{ uri: 'https://placeimg.com/140/140/any' }} size="medium" />
        <Text style={styles.profileText}>Rider: John Doe</Text>
        <Button title="Logout" buttonStyle={styles.logoutButton} onPress= {() => { /* Implement logout logic */ }} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0', // light gray background
  },
  map: {
    flex: 1,
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height / 2, // Half the screen height
  },
  card: {
    position: 'absolute',
    bottom: 10,
    left: 10,
    right: 10,
    padding: 16,
    borderRadius: 10,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333', // dark text color
    marginBottom: 10,
  },
  profile: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
  },
  profileText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
    textAlign: 'center',
  },
  logoutButton: {
    backgroundColor: '#e84118', // bright red color for the logout button
    padding: 10,
    borderRadius: 5,
  },
});

export default RiderHomeScreen;
