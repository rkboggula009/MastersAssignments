import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { Card, Button, Avatar, Icon } from 'react-native-elements';
import * as Location from 'expo-location';
import Config from '../api/urlConfig';

const RiderHomeScreen = ({ navigation, route }) => {
  const { ownerEmail } = route.params;
  const [showPopup, setShowPopup] = useState(false);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [pendingOrders, setPendingOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showMap, setShowMap] = useState(false); // State to control when to show the map

  useEffect(() => {
    const getLocation = async () => {
      try {
        let { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
          console.error('Permission to access location was denied');
          return;
        }

        let location = await Location.getCurrentPositionAsync({});
        setCurrentLocation(location.coords);
      } catch (error) {
        console.error('Error fetching location:', error);
      } finally {
        setLoading(false);
      }
    };

    const fetchPendingOrders = async () => {
      try {
        const response = await fetch(`${Config.API_URL}/pending-orders?ownerEmail=${ownerEmail}`);
        const data = await response.json();
        console.log(data);
        setPendingOrders(data);
      } catch (error) {
        console.log(ownerEmail);
        console.error('Error fetching pending orders:', error);
      }
    };

    getLocation();
    fetchPendingOrders();
  }, []);

  const handleMenu1Press = () => {
    //navigation.navigate('Rider_home');
  };

  const handleMenu2Press = () => {
    navigation.navigate('hist', { ownerEmail });
  };

  const handleAcceptOrder = async (orderId, riderEmail) => {
    try {
      const response = await fetch(`${Config.API_URL}/update-order/${orderId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ownerEmail }),
      });

      if (response.ok) {
        console.log('Order updated successfully');
      } else {
        throw new Error('Failed to update order');
      }
    } catch (error) {
      console.error('Error updating order:', error);
    }
  };

  const handleDeliveredOrder = async (orderId) => {
    try {
      const response = await fetch(`${Config.API_URL}/update-order-status/${orderId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: 'completed' }),
      });

      if (response.ok) {
        console.log('Order status updated to completed successfully');
        setShowPopup(true);
      } else {
        throw new Error('Failed to update order status to completed');
      }
    } catch (error) {
      console.error('Error updating order status to completed:', error);
    }
  };

  const onOrderPress = (order) => {
    setSelectedOrder(order);

    const { customerLatitude, customerLongitude, restaurantLatitude, restaurantLongitude } = order;
    const customerLatitudeFloat = parseFloat(customerLatitude);
    const customerLongitudeFloat = parseFloat(customerLongitude);
    const restaurantLatitudeFloat = parseFloat(restaurantLatitude);
    const restaurantLongitudeFloat = parseFloat(restaurantLongitude);

    const centerLatitude = (customerLatitudeFloat + restaurantLatitudeFloat) / 2;
    const centerLongitude = (customerLongitudeFloat + restaurantLongitudeFloat) / 2;

    setCurrentLocation({
      latitude: centerLatitude,
      longitude: centerLongitude
    });
    
    // Show the map when an order is selected
    setShowMap(true);
  };

  const handleLogout = () => {
    navigation.navigate('Login');
  };

  const handleUpdateMap = () => {
    // Toggle the showMap state to true
    setShowMap(true);
  };

  return (
    <View style={styles.container}>
      <View style={styles.topBar}>
        <Avatar rounded source={{ uri: 'https://placeimg.com/140/140/any' }} size="medium" />
        <Text style={styles.loggedInUserText}>{ownerEmail}</Text>
        <Button title="Logout" buttonStyle={styles.logoutButton} onPress={handleLogout} />
      </View>

      <View style={styles.mapContainer}>
        {loading ? (
          <ActivityIndicator style={styles.loader} size="large" color="#0000ff" />
        ) : showMap && currentLocation && (
          <MapView
            style={styles.map}
            initialRegion={{
              //40.352679194226845, -94.88267435978689
              latitude: currentLocation?.latitude || 40.346100,
              longitude: currentLocation?.longitude || -94.872948,
              latitudeDelta: 0.0922,
              longitudeDelta: 0.0421,
            }}
            region={currentLocation ? {
              latitude: currentLocation.latitude,
              longitude: currentLocation.longitude,
              latitudeDelta: 0.005,
              longitudeDelta: 0.005,
            } : undefined}
          >
            {currentLocation && !selectedOrder && (
              <Marker
                coordinate={currentLocation}
                title="Your Location"
                pinColor="blue"
              />
            )}

            {selectedOrder && (
              <>
                <Marker
                  coordinate={{
                    latitude: parseFloat(selectedOrder.customerLatitude),
                    longitude: parseFloat(selectedOrder.customerLongitude)
                  }}
                  title="Customer's Location"
                  pinColor="red"
                />
                <Marker
                  coordinate={{
                    latitude: parseFloat(selectedOrder.restaurantLatitude),
                    longitude: parseFloat(selectedOrder.restaurantLongitude)
                  }}
                  title="Restaurant's Location"
                  pinColor="green"
                />
              </>
            )}
          </MapView>
        )}
      </View>

      {showPopup && (
        <View style={styles.popupContainer}>
          <View style={styles.popup}>
            <Text style={styles.popupText}>Order delivered successfully!</Text>
            <TouchableOpacity onPress={() => setShowPopup(false)} style={styles.closeButton}>
              <Text style={styles.closeButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      <FlatList
        style={styles.ordersContainer}
        data={pendingOrders}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => onOrderPress(item)}>
            <Card containerStyle={styles.card}>
              <Card.Title>Pending Order</Card.Title>
              <Card.Divider />
              <Text>OrderId: {item.id}</Text>
              <Text>Customer: {item.customerId}</Text>
              <Text>Restaurant: {item.restaurant}</Text>
              <View style={{ flexDirection: 'row' }}>
                <TouchableOpacity onPress={() => handleAcceptOrder(item.id, ownerEmail)} style={styles.button}>
                  <Text style={styles.buttonText}>Accept</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => handleDeliveredOrder(item.id)} style={styles.button}>
                  <Text style={styles.buttonText}>Mark Delivered</Text>
                </TouchableOpacity>
              </View>
            </Card>
          </TouchableOpacity>
        )}
      />

      <View style={styles.footer}>
        <TouchableOpacity style={styles.footerItem} onPress={handleMenu1Press}>
          <Icon name="menu" type="material" size={24} color="black" />
          <Text>Menu 1</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.footerItem} onPress={handleMenu2Press}>
          <Icon name="menu" type="material" size={24} color="black" />
          <Text>History</Text>
        </TouchableOpacity>
      </View>

      {/* Add the Update Map button */}
      <Button title="Update Map" onPress={handleUpdateMap} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
    backgroundColor: 'white',
    borderRadius: 10,
    margin: 10,
    elevation: 5,
  },
  mapContainer: {
    flex: 1,
    borderRadius: 10,
    margin: 10,
    overflow: 'hidden',
  },
  map: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  ordersContainer: {
    flex: 1,
    margin: 10,
  },
  card: {
    borderRadius: 0,
    backgroundColor: 'white',
    elevation: 0,
  },
  profileText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  logoutButton: {
    backgroundColor: '#e84118',
    padding: 10,
    borderRadius: 5,
  },
  loader: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: 'white',
    paddingVertical: 5,
  },
  footerItem: {
    alignItems: 'center',
  },
  buttonContainer: {
    flexDirection: 'column',
  },
  button: {
    backgroundColor: 'green',
    padding: 3,
    borderRadius: 5,
    marginBottom: 16,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  popupContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  popup: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    elevation: 5,
  },
  popupText: {
    fontSize: 18,
    marginBottom: 10,
  },
  closeButton: {
    backgroundColor: '#2196F3',
    padding: 10,
    borderRadius: 5,
    alignSelf: 'flex-end',
  },
  closeButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default RiderHomeScreen;
