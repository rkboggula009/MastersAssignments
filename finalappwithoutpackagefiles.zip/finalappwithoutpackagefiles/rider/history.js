import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity,Image } from 'react-native';
import { Header, Icon } from 'react-native-elements';
import { MaterialIcons } from '@expo/vector-icons'; // Import MaterialIcons for chat icon
import { useNavigation } from '@react-navigation/native'; // Import useNavigation hook to handle navigation
import Config from '../api/urlConfig'; // Import your API URL configuration file

const HistoryScreen = ({ route }) => {
  const { ownerEmail } = route.params;
  const [historyOrders, setHistoryOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigation = useNavigation(); // Initialize navigation

  useEffect(() => {
    const fetchHistoryOrders = async () => {
      try {
        const response = await fetch(`${Config.API_URL}/history?riderEmail=${ownerEmail}`);
        const data = await response.json();
        setHistoryOrders(data);
      } catch (error) {
        console.error('Error fetching historical orders:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchHistoryOrders();
  }, []);

  const renderOrderDetails = (item) => {
    // Render all order details here
    return (
      <View style={styles.orderDetailsContainer}>
        <Text style={styles.orderDetailText}>Order ID: {item.id}</Text>
        <Text style={styles.orderDetailText}>Customer : {item.customerId}</Text>
        <Text style={styles.orderDetailText}>Restaurant : {item.restaurant}</Text>
        <Text style={styles.orderDetailText}>Amount: {item.totalAmount}</Text>
        <Text style={styles.orderDetailText}>Status: {item.status}</Text>
        <TouchableOpacity>
          <Image source={require('../assets/logo.png')} style={styles.image} />
        </TouchableOpacity>
        
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Header
        backgroundColor="#FFA500"
        leftComponent={
          <TouchableOpacity onPress={() => navigation.navigate('Rider_home',{ ownerEmail: ownerEmail })}>
            <MaterialIcons name="arrow-back" size={24} color="white" />
          </TouchableOpacity>
        }
        centerComponent={{ text: 'Historical Orders', style: { color: '#fff', fontSize: 20, fontWeight: 'bold' } }}
      />
      {loading ? (
        <View style={styles.loaderContainer}>
          <ActivityIndicator size="large" color="#FFA500" />
        </View>
      ) : (
        <FlatList
          data={historyOrders}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <View style={styles.orderItem}>
              {renderOrderDetails(item)}
              {/* Add more order details to display */}
            </View>
          )}
        />
      )}
      <View style={styles.footer}>
      {ownerEmail && (  
        <TouchableOpacity >
          <Text style={styles.footerItem}></Text>
        </TouchableOpacity>
      )}
      <TouchableOpacity onPress={() => navigation.navigate('chaa')}>
        <Icon name="chat" type="material" color="#fff" />
      </TouchableOpacity>
    </View>

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  orderItem: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  orderDetailsContainer: {
    marginBottom: 10,
  },
  orderDetailText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: '#FFA500',
    paddingVertical: 10,
  },
  footerItem: {
    color: '#fff',
    fontSize: 16,
  },
  
  image: {
    width: 50, 
    height: 50, 
    marginLeft: 'auto',
    marginTop: -30,
  },
});

export default HistoryScreen;
